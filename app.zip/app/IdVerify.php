<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IdVerify extends Model
{
    //
}
