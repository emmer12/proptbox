<?php

return [
    "reset_password_url" =>env('FRONT_END_RESET_PASSWORD_URL')
];