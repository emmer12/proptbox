@extends('layouts.universe')

@section('content')
<div class="">
   <h1>This about Page</h1>
</div>
@endsection
