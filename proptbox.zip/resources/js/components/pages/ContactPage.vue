<template>
     <div class="abot">
         <h1>This is about</h1>
     </div>
</template>

<script>
export default {

}
</script>

<style>

</style>