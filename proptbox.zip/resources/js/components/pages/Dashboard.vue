<template>
  <div class="dashboard">
      <setting-view></setting-view>
  </div>
</template>

<script>
import SettingView from "../partials/Settingview";

export default {
components:{
  SettingView
},
data() {
  return {
  }
},
methods: {
},
created() {
},

}
</script>
