<template>
  <div class="about-2">
    <div class="banner">
      <h4>Terms And Conditions</h4>
      <div>
      </div>
    </div>

    <div class="body">
      <div class="container">
     
        <div class="row justify-content-center">
        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>PRIVACY POLICY</h4>
          </div>

          <div class="body">
            <p>
              Thank you for accessing Proptybox.com website. We respect your privacy and want to protect your personal information. To learn more, please read this Privacy Policy. This Privacy Policy explains how we collect, use and (under certain conditions) disclose your personal information. This Privacy Policy also explains the steps we have taken to secure your personal information. Finally, this Privacy Policy explains your options regarding the collection, use and disclosure of your personal information. By visiting the Site directly or through another site, you accept the
              practices described in this Policy. Data protection is a matter of trust and your privacy is important to us. We shall therefore only use your name and other information which relates to you in the manner set out in this Privacy Policy. We will only collect information where it is necessary for us to do so and we will only collect information if it is relevant to our dealings with you. We Will only keep your information for as long as we are either required to by law or as is relevant for the purposes for which it was collected. You can visit the Site and browse without having to provide personal details. During your visit to the Site you remain anonymous and at no time can we identify you unless you have an account on the Site and log on with your user name and password.
            </p>
          </div>
        </section>
        </div>
        <div class="row justify-content-center">

        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>Collection of personal information</h4>
          </div>

          <div class="body">
            <p>We may collect various pieces of information if you seek to place an order for a service/product with us on the Site. We collect, store and process your data for processing your purchase on the Site and any possible later claims, and to provide you with our services. We may collect personal information including, but not limited to, your title, name, gender, email address, telephone number, mobile number, payment details, payment card details or bank account details. We will use the information you provide to enable us to process your orders and to provide you with the services and information offered through our website and which you request. Further, we will use the information you provide to administer your account for verifications audit the downloading of data from our website; improve the layout and/or content of the pages of our website and customize them for users; identify visitors on our website; carry out research on our users' demographics; send you information we think you may find useful or which you have requested from us, including information about our services, provided you have indicated that you have not objected to being contacted for these purposes. Subject to obtaining your consent we may contact you by email with details of other services. If you prefer not to receive any marketing communications from us, you can opt out at any time. We may pass your name and address on to a third party in order to make a deal that suits your search options. You undertake to treat the personal access data confidentially and not make it available to unauthorized third parties. We cannot assume any liability for misuse of passwords unless this misuse is our fault.</p>
            <p>We may pass your details to other companies in our group. We may also pass your details to our agents and subcontractors to help us with any of our uses of your data set out in our Privacy Policy. For example, we may use third parties to assist us with delivering products to you, to analyze data and to provide us with marketing or customer service assistance.</p>
            <p>We may exchange information with third parties for the purposes of fraud protection and credit risk reduction. We may transfer our databases containing your personal information if we sell our business or part of it. Other than as set out in this Privacy Policy, we shall NOT sell or disclose your personal data to third parties without obtaining your prior consent unless this is necessary for the purposes set out in this Privacy Policy or unless we are required to do so by law. The Site may contain advertising of third parties and links to other sites or frames of other sites. Please be aware that we are not responsible for the privacy practices or content of those third parties or other sites, nor for any third party to whom we transfer your data in accordance with our Privacy Policy.</p>
          </div>
        </section>
        </div>
        <div class="row justify-content-center">

        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>Cookies</h4>
          </div>

          <div class="body">
            <p>The acceptance of cookies is not a requirement for visiting the Site. Cookies are tiny text files which identify your computer to our server as a unique user when you visit certain pages on the Site and they are stored by your Internet browser on your computer's hard drive. Cookies can be used to recognize your Internet Protocol address, saving you time while you are on, or want to enter, the Site. We only use cookies for your convenience in using the Site (for example to remember who you are without having to re-enter your email address) and not for obtaining or using any other information about you (for example targeted advertising). Your browser can be set to not accept cookies, but this would restrict your use of the Site. Please accept our assurance that our use of cookies does not contain any personal or private details and are free from viruses. If you want to find out more information about cookies, go to http://www.allaboutcookies.org or to find out about removing them from your browser, go to http://www.allaboutcookies.org/manage-cookies/index.html.</p>
          </div>
        </section>
        </div>
        <div class="row justify-content-center">

        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>Security</h4>
          </div>

          <div class="body">
            <p>We have in place appropriate technical and security measures to prevent unauthorized or unlawful access to or accidental loss of or destruction or damage to your information. When we collect data through the Site, we collect your personal details on a secure server. We use firewalls on our servers. we use encryption by using Secure Socket Layer (SSL) coding. While we are unable to guarantee 100% security, this makes it hard for a hacker to decrypt your details. We maintain physical, electronic and procedural safeguards in connection with the collection, storage and disclosure of your information. You are responsible for protecting against unauthorized access to your password and to your computer.</p>
          </div>
        </section>
        </div>

        <div class="row justify-content-center">
        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>Disclaimer</h4>
          </div>

          <div class="body">
            <p>If you are concerned about your data you have the right to request access to the personal data which we may hold or process about you. You have the right to require us to correct any inaccuracies in your data free of charge. At any stage you also have the right to ask us to stop using your personal data for direct marketing purposes.</p>
          </div>
        </section>
        </div>

        <div class="row justify-content-center">
        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>TERMS & CONDITIONS</h4>
          </div>

          <div class="body">
            <p>This document is an electronic record in terms of National Information Technology Development Agency Act, 2014 and rules there under as applicable and the amended provisions pertaining to electronic records in various statutes as amended by the National Information Technology Development Agency Act, 2014. This electronic record is generated by a computer system and does not require any physical or digital signatures.</p>
            <p>Welcome to the Proptybox.com website (the "Site"). These terms & conditions ("Terms and Conditions") apply to the Site, and all of its divisions, subsidiaries, and affiliate operated Internet sites which reference these Terms and Conditions. We form legal agreement under the registered business name FEMI &SAMI BUILDING INTERIOR AND SERVICES LIMITED . For the purposes of this website, "seller", "we", "us" and "our" all refer Proptybox.com</p>
            <p>YOU ACCEPT THESE TERMS OF USE BY CLICKING THE "REGISTER" BUTTON WHEN REGISTERING YOUR ACCOUNT AND BY ACCESSING OR OTHERWISE BROWSING THE SITE INDICATES YOUR AGREEMENT TO ALL THE TERMS AND CONDITIONS IN THIS AGREEMENT, SO PLEASE READ THIS AGREEMENT CAREFULLY BEFORE PROCEEDING</p>
          </div>
        </section>
        </div>

        <div class="row justify-content-center">

        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>USE OF THE SITE</h4>
          </div>

          <div class="body">
            <p>Use of the Proptybox.com Website is available only to persons who can form legally binding contracts under Nigerian governing laws. If you are a minor i.e. under the age of 18 years, you shall not register as a user on Proptybox.com website. As a minor if you wish to register as a user on Proptybox.com, such use may be made by your legal guardian or parents who have registered as users of Proptybox.com. Both parties agree that this website may only be used in accordance with these Terms and Conditions of Use. If you do not agree with the Terms and Conditions of Use or do not wish to be bound by them, you agree to refrain from using this website. We grant you a non-transferable, revocable and non-exclusive license to use this Site, in accordance with the Terms and Conditions of Use. Commercial use or use on behalf of any third party is prohibited, except as explicitly permitted by us in advance. If you use shopaholiqstores.com you shall be responsible for maintaining the confidentiality of your User ID and Password and you shall be responsible for all activities that occur under your User ID and Password. You agree that if you provide any information that is untrue, inaccurate, not current or incomplete that Proptybox.com has reasonable grounds to suspect that such information is untrue, inaccurate, not current or incomplete, or not in accordance with the this Terms of Use, Proptybox.com has the right to indefinitely suspend or terminate or block access of your membership with Proptybox.com and refuse to provide you with access to the Website.</p>
            <p>When You use the Website or send emails or other data, information or communication to Proptybox.com, You agree and understand that You are communicating with Proptybox.com through electronic records and You consent to receive communications via electronic records from Proptybox.com periodically and as and when required. Proptybox.com may communicate with you by email or by such other mode of communication, electronic or otherwise.</p>
            <p>You accept that the information contained in this website is provided “as is, where is”, is intended for information purposes only and that it is subject to change without notice. Although we take reasonable steps to ensure the accuracy of information and we believe the information to be reliable when posted, it should not be relied upon and it does not in any way constitute either a representation or a warranty or a guarantee.</p>
            <p>listings, properties and services representations expressed on this Site are those of the vendor and are not made by us. Submissions or opinions expressed on this Site are those of the individual posting such content and may not reflect our opinions.</p>
            <p>Membership on Proptybox.com is free and does not charge any fee for browsing and buying on Proptybox.com. However Proptybox.com reserves the right to charge fee and change its policies from time to time. In particular, Proptybox.com may at its sole discretion introduce new services and modify some or all of the existing services offered on Proptybox.com. In such an event Proptybox.com reserves, without notice to You, the right to introduce fees for the new services offered or amend/introduce fees for existing services, as the case may be. Changes to the Fee and related policies shall automatically become effective immediately once implemented on Proptybox.com. Unless otherwise stated, all fees shall be quoted in Nigerian Naira.</p>
            <p></p>
          </div>
        </section>
        </div>

        <div class="row justify-content-center">
        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>Use of Proptybox.com Website www. Proptybox.com</h4>
          </div>

          <div class="body">
            <p>You agree, undertake and confirm that your use of Proptybox.com shall be strictly governed by the following binding principles:You shall not host, display, upload, modify, publish, transmit, update or share any information that:</p>
            <div>
              <ul>
                <li>belongs to another person and to which You do not have any right to.</li>
                <li>is grossly harmful, harassing, blasphemous, defamatory, obscene, pornographic, paedophilic, libellous, invasive of another's privacy, hateful, or racially, ethnically objectionable, disparaging, relating or encouraging money laundering or gambling, or otherwise unlawful in any manner whatever; or unlawfully threatening or unlawfully harassing including but not limited to "indecent representation of women" or misleading in any way.</li>
                <li>is patently offensive to the online community, such as sexually explicit content, or content that promotes obscenity, pedophilia, racism, bigotry, hatred or physical harm of any kind against any group or individual;</li>
                <li>harasses or advocates harassment of another person;</li>
                <li>involves the transmission of "junk mail," "chain letters," or unsolicited mass mailing or "spamming";</li>
                <li>promotes illegal activities or conduct that is abusive, threatening, obscene, defamatory or libelous;</li>
                <li>infringes upon or violates any third party's rights [(including, but not limited to, intellectual property rights, rights of privacy (including without limitation unauthorized disclosure of a person's name, email address, physical address or phone number) or rights of publicity];</li>
                <li>promotes an illegal or unauthorized copy of another person's copyrighted work (see "Copyright complaint" below for instructions on how to lodge a complaint about uploaded copyrighted material), such as providing pirated computer programs or links to them, providing information to circumvent manufacture-installed copy-protect devices, or providing pirated music or links to pirated music files;</li>
                <li>contains restricted or password-only access pages, or hidden pages or images (those not linked to or from another accessible page);</li>
                <li>provides material that exploits people in a sexual, violent or otherwise inappropriate manner or solicits personal information from anyone;</li>
                <li>provides instructional information about illegal activities such as making or buying illegal weapons, violating someone's privacy, or providing or creating computer viruses;</li>
                <li>contains video, photographs, or images of another person age 18 or older without his or her express written consent and permission or those of any minor (regardless of whether you have consent from the minor or his or her legal guardian).</li>
                <li>tries to gain unauthorized access or exceeds the scope of authorized access (as defined herein and in other applicable Codes of Conduct or End User Access and License Agreements) to the Sites or to profiles, blogs, communities, account information, bulletins, friend request, or other areas of the Sites or solicits passwords or personal identifying information for commercial or unlawful purposes from other users;</li>
                <li>engages in commercial activities and/or sales without Proptybox.com's prior written consent such as contests, sweepstakes, barter, advertising and pyramid schemes, or the buying or selling of "virtual" items related to the Sites. Throughout this Terms of Use, Proptybox.com "prior written consent" means a communication coming from Proptybox.com Legal department, specifically in response to your request, and specifically addressing the activity or conduct for which you seek authorization;</li>
                <li>solicits gambling or engages in any gambling activity which Proptybox.com, in its sole discretion, believes is or could be construed as being illegal;</li>
                <li>interferes with another user's use and enjoyment of Proptybox.com Website or any other individual's user and enjoyment of similar services;</li>
                <li>refers to any website or URL that, in the sole discretion of Proptybox.com, contains material that is inappropriate for the Proptybox.com Website or any other Website, contains content that would be prohibited or violates the letter or spirit of these Terms of Use.</li>
                <li>harm minors in any way;</li>
                <li>infringes any patent, trademark, copyright or other proprietary rights or third party’s trade secrets or rights of publicity or privacy or shall not be fraudulent or involve the sale of counterfeit or stolen items;</li>
                <li>violates any law for the time being in force;</li>
                <li>deceives or misleads the addressee/ users about the origin of such messages or communicates any information which is grossly offensive or menacing in nature;</li>
                <li>impersonate another person;</li>
                <li>contains software viruses or any other computer code, files or programs designed to interrupt, destroy or limit the functionality of any computer resource; or contains any Trojan horses, worms, time bombs, cancelbots, easter eggs or other computer programming routines that may damage, detrimentally interfere with, diminish value of, surreptitiously intercept or expropriate any system, data or personal information;</li>
                <li>threatens the unity, integrity, defense, security or sovereignty of The Federal Republic of Nigeria, friendly relations with foreign states, or public order or causes incitement to the commission of any cognizable offence or prevents investigation of any offence or is insulting any other nation.</li>
                <li>shall not be false, inaccurate or misleading;</li>
                <li>shall not, directly or indirectly, offer, attempt to offer, trade or attempt to trade in any item, the dealing of which is prohibited or restricted in any manner under the provisions of any applicable law, rule, regulation or guideline for the time being in force.</li>
              </ul>
              <p>You shall not use any “deep-link”, “page-scrape”, “robot”, “spider” or other automatic device, program, algorithm or methodology, or any similar or equivalent manual process, to access, acquire, copy or monitor any portion of the Website or any Content, or in any way reproduce or circumvent the navigational structure or presentation of the Website or any Content, to obtain or attempt to obtain any materials, documents or information through any means not purposely made available through the Website. Proptybox.com reserves the right to bar any such activity.</p>
              <p>You shall not attempt to gain unauthorized access to any portion or feature of shopaholiqstores.com website, or any other systems or networks connected to Proptybox.com Website or to any Proptybox.com server, computer, network, or to any of the services offered on or through Proptybox.com Website, by hacking, password “mining” or any other illegitimate means.</p>
              <p>You shall not probe, scan or test the vulnerability of Proptybox.com website or any network connected to Proptybox.com website nor breach the security or authentication measures on Proptybox.com website or any network connected to Proptybox.com Website. You may not reverse look-up, trace or seek to trace any information on any other user of or visitor to Proptybox.com Website, or any other customer of Proptybox.com, including any Proptybox.com account not owned by you, to its source, or exploit shopaholiqstores.com Website or any service or information made available or offered by or through Proptybox.com Website, in any way where the purpose is to reveal any information, including but not limited to personal identification or information, other than your own information, as provided for by Proptybox.com Website. You agree that you will not take any action that imposes an unreasonable or disproportionately large load on the infrastructure of Website or Proptybox.com systems or networks, or any systems or networks connected to Proptybox.com. You agree not to use any device, software or routine to interfere or attempt to interfere with the proper working of the Website or any transaction being conducted on the Website, or with any other person’s use of the Website.</p>
              <p>You may not forge headers or otherwise manipulate identifiers in order to disguise the origin of any message or transmittal you send to Proptybox.com on or through the Website or any service offered on or through the Website. You may not pretend that you are, or that you represent, someone else, or impersonate any other individual or entity.</p>
              <p>You may not use the Website or any Content for any purpose that is unlawful or prohibited by these Terms of Use, or to solicit the performance of any illegal activity or other activity which infringes the rights of Proptybox.com or others.</p>
              <p>Solely to enable Proptybox.com to use the information you supply us with, so that we are not violating any rights you might have in Your Information, you agree to grant us a non-exclusive, worldwide, perpetual, irrevocable, royalty-free, sub-licensable (through multiple tiers) right to exercise the copyright, publicity, database rights or any other rights you have in Your Information, in any media now known or not currently known, with respect to Your Information. Proptybox.com will only use Your Information in accordance with the terms of use and Proptybox.com Privacy Policy.</p>\
              <p>From time to time, you shall be responsible for providing information relating to the items or services proposed to be sold by you. In this connection, you undertake that all such information shall be accurate in all respects. You shall not exaggerate or over emphasize the attributes of such items or services so as to mislead other Users in any manner.</p>
              <p>You shall not engage in advertising to, or solicitation of, other users of Proptybox.com to buy or sell any products or services, including, but not limited to, products or services related being displayed on Proptybox.com or related to Proptybox.com In order to protect our users from such advertising or solicitation, Proptybox.com reserves the right to restrict the number of messages or emails which a user may send to other users in any 24-hour period Proptybox.com deems appropriate in its sole discretion.12. You understand that Proptybox.com has the right at all times to disclose any information (including the identity of the persons providing information or materials on the Proptybox.com Website) as necessary to satisfy any law, regulation or valid governmental request. This may include, without limitation, disclosure of the information in connection with investigation of alleged illegal activity or solicitation of illegal activity or in response to a lawful court order or subpoena. In addition, we can (and you hereby expressly authorize us to) disclose any information about you to law enforcement or other government officials, as we, in our sole discretion, believe necessary or appropriate in connection with the investigation and/or resolution of possible crimes, especially those that may involve personal injury.</p>
              <p>Proptybox.com reserves the right, but has no obligation, to monitor the materials posted on Proptybox.com website. Proptybox.com shall have the right to remove or edit any Content that in its sole discretion violates, or is alleged to violate, any applicable law or either the spirit or letter of these Terms of Use. Notwithstanding this right of Proptybox.com, YOU REMAIN SOLELY RESPONSIBLE FOR THE CONTENT OF THE MATERIALS YOU POST ON THE PROPTYBOX.COM WEBSITE AND IN YOUR PRIVATE MESSAGES. Please be advised that such Content posted does not necessarily reflect the views of Proptybox.com In no event shall Proptybox.com assume or have any responsibility or liability for any Content posted or for any claims, damages or losses resulting from use of Content and/or appearance of Content on Proptybox.com. You hereby represent and warrant that you have all necessary rights in and to all Content you provide and all information it contains and that such Content shall not infringe any proprietary or other rights of third parties or contain any libelous, tortuous, or otherwise unlawful information</p>
              <p>Your correspondence or business dealings with, or participation in promotions of, advertisers found on or through Proptybox.com including payment and delivery of related goods or services, and any other terms, conditions, warranties or representations associated with such dealings, are solely between you and such advertiser. Proptybox.com shall not be responsible or liable for any loss or damage of any sort incurred as the result of any such dealings or as the result of the presence of such advertisers on Proptybox.com.</p>
              <p>It is possible those other users (including unauthorized users or “hackers”) may post or transmit offensive or obscene materials on Proptybox.com and that you may be involuntarily exposed to such offensive and obscene materials. It also is possible for others to obtain personal information about you due to your use of shopaholiqstores.com, and that the recipient may use such information to harass or injure you. Proptybox.com does not approve of such unauthorized uses but by using the Proptybox.com Website you acknowledge and agree that Proptybox.com is not responsible for the use of any personal information that you publicly disclose or share with others on Proptybox.com. Please carefully select the type of information that you publicly disclose or share with others on Proptybox.com.</p>
              <p>Proptybox.com shall have all the rights to take necessary action and claim damages that may occur due to your involvement/participation in any way on your own or through group/s of People, intentionally or unintentionally in DoS/DDoS (Distributed Denial of Services).</p>
            </div>
          </div>
        </section>
        </div>

        <div class="row justify-content-center">
        <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>APPLICABLE LAW AND JURISDICTION</h4>
          </div>

          <div class="body">
            <p>These Terms and Conditions of Use shall be interpreted and governed by the laws in force in the Federal Republic of Nigeria. Subject to the Arbitration section below, each party hereby agrees to submit to the jurisdiction of the courts of Nigeria and to waive any objections based upon venue.</p>
          </div>
        </section>
        </div>

        <div class="row justify-content-center">
         <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>TERMINATION</h4>
          </div>

          <div class="body">
            <p>In addition to any other legal or equitable remedies, we may, without prior notice to you, immediately terminate the Terms and Conditions of Use or revoke any or all of your rights granted under the Terms and Conditions of Use.</p>
            <p>Upon any termination of this Agreement, you shall immediately cease all access to and use of the Site and we shall, in addition to any other legal or equitable remedies, immediately revoke all password(s) and account identification issued to you and deny your access to and use of this Site in whole or in part.</p>
            <p>Any termination of this agreement shall not affect the respective rights and obligations (including without limitation, payment obligations) of the parties arising before the date of termination. You furthermore agree that the Site shall not be liable to you or to any other person as a result of any such suspension or termination.</p>
            <p>If you are dissatisfied with the Site or with any terms, conditions, rules, policies, guidelines, or practices of FEMI & SANMI BUILDING INTERIOR AND SERVICES LIMITED in operating the Site, your sole and exclusive remedy is to discontinue using the Site.</p>
          </div>
        </section>
        </div>

        <div class="row justify-content-center">
         <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>MISCELLANEOUS PROVISIONS</h4>
          </div>

          <div class="body">
            <p>You agree that all agreements, notices, disclosures and other communications that we provide to you electronically satisfy any legal requirement that such communications be in writing.</p>
            <p>Assigning or sub-contracting any of your rights or obligations under these Terms and Conditions of Use to any third party is prohibited unless agreed upon in writing by the seller.</p>
            <p>We reserve the right to transfer, assign or sub-contract the benefit of the whole or part of any rights or obligations under these Terms and Conditions of Use to any third party.</p>

          </div>
        </section>
        </div>

        <div class="row justify-content-center">
         <section  class="col-md-6 col-sm-12 col-xs-12">
          <div class="heading">
            <h4>CONTENT POSTED ON SITE</h4>
          </div>

          <div class="body">
            <p>All text, graphics, user interfaces, visual interfaces, photographs, trademarks, logos, sounds, music, artwork and computer code (collectively, “Content”), including but not limited to the design, structure, selection, coordination, expression, “look and feel” and arrangement of such Content, contained on Proptybox.com is owned, controlled or licensed by or to Proptybox.com, and is protected by trade dress, copyright, patent and trademark laws, and various other intellectual property rights and unfair competition laws.</p>
            <p>Except as expressly provided in these Terms of Use, no part of Proptybox.com and no Content may be copied, reproduced, re-published, uploaded, posted, publicly displayed, encoded, translated, transmitted or distributed in any way (including “mirroring”) to any other computer, server, website or other medium for publication or distribution or for any commercial enterprise, without express prior written consent.</p>
            <p>You may use information on Proptybox.com products and services purposely made available by Proptybox.com for downloading from the Site, provided that you (1) not remove any proprietary notice language in all copies of such documents, (2) use such information only for your personal, non-commercial informational purpose and do not copy or post such information on any networked computer or broadcast it in any media, (3) make no modifications to any such information, and (4) not make any additional representations or warranties relating to such documents.</p>
            <p>You shall be responsible for any notes, messages, e-mails, billboard postings, photos, drawings, profiles, opinions, ideas, images, videos, audio files or other materials or information posted or transmitted to the Sites (collectively, "Content"). Such Content will become the property of Proptybox.com and you grant Proptybox.com the worldwide, perpetual and transferable rights in such Content. </p>
          </div>
        </section>
        </div>


      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>


<style lang="scss" scoped>
.about-2 {
  .banner {
    height: 200px;
    // background:rgb(173, 3, 3);
    background: #eef4ff;

    h4 {
      color: #333;
      font-weight: 700;
      position: relative;
      top: 50%;
      margin-left: 40px;
      padding: 10px;
      border-left: 4px solid #5895f9;
      &::before {
        content: "";
        position: absolute;
        height: 4px;
        width: 50px;
        background: #5895f9;
        bottom: 0px;
        left: -10px;
      }
    }

    div {
      //   float: right;
      top: -30px;
      position: relative;

      img {
        display: block;
        position: absolute;
        right: 20px;
      }
    }
  }

  .body {
    margin-top: 33px;
    padding: 10px;
    p {
      font-size: 16px;
    }
  }
}
</style>