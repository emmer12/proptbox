<template>
  <div>
      This is guest list
  </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
   methods: {
       getListing(){
           
       }
   } 
}
</script>
   
<style>
   
</style>